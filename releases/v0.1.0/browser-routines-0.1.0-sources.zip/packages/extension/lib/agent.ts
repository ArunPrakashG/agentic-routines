import type { Locator, PageFingerprint, RecordedEvent } from '@browser-routines/core';
import { areaBase64, cropHash, pngBase64, type Rect } from './crop';
import * as native from './native';
import { platform } from './platform';
import * as runs from './runs';
import { agentTabId, ask, settle, setAgentTab, waitLoaded } from './tabs';

// The browser tools agents call. Each call is done and recorded.

interface Described {
  loc: Locator;
  rect: Rect;
  field: RecordedEvent['field'];
  label: string;
  page: PageFingerprint;
}

const AGENTS: Record<string, string> = {
  'claude-code': 'Claude Code',
  'codex-mcp-client': 'Codex',
  codex: 'Codex',
  'Visual Studio Code': 'GitHub Copilot',
  'visual-studio-code': 'GitHub Copilot',
  opencode: 'OpenCode',
};
export const agentName = (raw?: string) => (raw ? (AGENTS[raw] ?? raw) : 'Agent');

/** Put a local file into a file input. With a DevTools session the path is set directly; otherwise it streams through the host. */
export async function uploadFile(tabId: number, ref: string, path: string) {
  if (platform.cdp && (await ask<boolean>(tabId, { t: 'markUpload', ref }))) {
    await platform.cdp(tabId, async (send) => {
      const { result } = await send<any>('Runtime.evaluate', { expression: 'document.querySelector("[data-br-upload]")' });
      await send('DOM.setFileInputFiles', { files: [path], objectId: result.objectId });
      await send('Runtime.evaluate', { expression: 'document.querySelector("[data-br-upload]").removeAttribute("data-br-upload")' });
    });
    return;
  }
  const parts: string[] = [];
  let offset = 0;
  let name = path.split(/[\\/]/).pop() ?? 'file';
  for (;;) {
    const c = await native.call<{ name: string; size: number; data: string }>('fs.readChunk', { path, offset });
    name = c.name;
    parts.push(c.data);
    offset += (c.data.length * 3) / 4 - (c.data.endsWith('==') ? 2 : c.data.endsWith('=') ? 1 : 0);
    if (offset >= c.size || !c.data) break;
  }
  const bin = parts.map((p) => atob(p)).join('');
  await ask(tabId, { t: 'attach', ref, files: [{ name, type: '', b64: btoa(bin) }] });
}

// The element a default screenshot centres on.
let lastActed: { tabId: number; ref: string } | undefined;

async function act(source: string, session: string | undefined, tabId: number, ref: string, action: RecordedEvent['action'], value?: string, extra: Partial<RecordedEvent> = {}) {
  const d = await ask<Described>(tabId, { t: 'describe', ref });
  const crop = d.field === 'password' ? undefined : await cropHash(tabId, d.rect);
  const before = (await browser.tabs.get(tabId)).url ?? '';
  if (action === 'upload') await uploadFile(tabId, ref, value!);
  else await ask(tabId, { t: 'act', ref, action, value });
  const after = await settle(tabId, before);
  // A new address can reuse refs for other elements.
  lastActed = after === before ? { tabId, ref } : undefined;
  await runs.record(source, {
    action,
    url: before,
    ts: Date.now(),
    target: d.loc,
    field: d.field,
    fieldLabel: d.label,
    // A password the agent typed is never kept.
    value: d.field === 'password' ? undefined : value,
    page: d.page,
    crop,
    navigatedTo: after !== before ? after : undefined,
    ...extra,
  }, session);
  return { d, after, changed: after !== before };
}

export async function handle(method: string, p: any): Promise<unknown> {
  const source = agentName(p?.agent);
  switch (method) {
    case 'browser.tabs': {
      const tabs = await browser.tabs.query({});
      return tabs.filter((t) => /^https?:/.test(t.url ?? '')).map((t) => ({ id: t.id, title: t.title, url: t.url, active: t.active }));
    }
    case 'browser.navigate': {
      let tabId: number;
      if (p.new_tab) {
        const t = await browser.tabs.create({ url: p.url, active: true });
        tabId = t.id!;
        setAgentTab(tabId);
      } else {
        tabId = await agentTabId(p.tab_id);
        await browser.tabs.update(tabId, { url: p.url, active: true });
      }
      await new Promise((r) => setTimeout(r, 200));
      await waitLoaded(tabId);
      const t = await browser.tabs.get(tabId);
      await runs.record(source, { action: 'navigate', url: t.url ?? p.url, ts: Date.now() }, p?.session);
      return { url: t.url, title: t.title, tab_id: tabId };
    }
    case 'browser.read': {
      const tabId = await agentTabId(p.tab_id);
      return ask<string>(tabId, { t: 'read', filter: p.filter });
    }
    case 'browser.click': {
      const tabId = await agentTabId(p.tab_id);
      const { d, after, changed } = await act(source, p?.session, tabId, p.ref, 'click');
      return `Clicked “${d.label || d.loc.name || d.loc.tag}”.${changed ? ` Now at ${after}` : ''}`;
    }
    case 'browser.type': {
      const tabId = await agentTabId(p.tab_id);
      const { d } = await act(source, p?.session, tabId, p.ref, 'type', p.text);
      if (p.submit) await act(source, p?.session, tabId, p.ref, 'press', 'Enter');
      return `Typed into “${d.label || d.loc.name || d.loc.tag}”.`;
    }
    case 'browser.select': {
      const tabId = await agentTabId(p.tab_id);
      const { d } = await act(source, p?.session, tabId, p.ref, 'select', p.value);
      return `Picked “${p.value}” in “${d.label}”.`;
    }
    case 'browser.upload': {
      const tabId = await agentTabId(p.tab_id);
      const { d } = await act(source, p?.session, tabId, p.ref, 'upload', p.path, { field: 'file' });
      return `Attached ${p.path.split(/[\\/]/).pop()} to “${d.label || d.loc.name}”.`;
    }
    case 'browser.press': {
      const tabId = await agentTabId(p.tab_id);
      const before = (await browser.tabs.get(tabId)).url ?? '';
      await ask(tabId, { t: 'act', action: 'press', value: p.key });
      const after = await settle(tabId, before);
      await runs.record(source, { action: 'press', url: before, value: p.key, ts: Date.now(), navigatedTo: after !== before ? after : undefined }, p?.session);
      return `Pressed ${p.key}.`;
    }
    case 'browser.screenshot': {
      const tabId = await agentTabId(p.tab_id);
      if (p.full) return { data: await pngBase64(tabId), note: 'The whole tab.' };
      const ref: string | undefined = p.ref ?? (lastActed?.tabId === tabId ? lastActed.ref : undefined);
      const d = ref ? await ask<Described>(tabId, { t: 'describe', ref }).catch((e) => { if (p.ref) throw e; }) : undefined;
      const { data, area } = await areaBase64(tabId, d?.rect);
      return { data, note: area ? `The area around “${d!.label || d!.loc.name || d!.loc.tag}”. Pass full: true for the whole tab.` : 'The whole tab at half size, as no element was acted on here. Pass full: true for full size.' };
    }
    case 'runs.get':
      return runs.get(p?.run_id, p?.session);
    default:
      throw new Error(`Unknown method ${method}`);
  }
}
