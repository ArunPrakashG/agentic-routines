# Agent tools

The `agentic-routines mcp` command is a Model Context Protocol server that your agent starts over stdio. `setup` writes the config for each agent so you never run it yourself.

## Browser tools

Your agent works in its own tab unless told otherwise. Everything it does with these is recorded.

| Tool | What it does |
|---|---|
| `tabs` | List open tabs: id, title and address. |
| `dialog` | Answer an alert, confirm or prompt that has stopped the page. Recorded as a step; yes to one that sounds final pauses a replay. |
| `javascript` | Run a script in the page. It cannot read cookies, will not run in a tab where a secret was typed, and hides values that look like credentials. Never recorded. |
| `read_console_messages` | What the page said to its console, and uncaught errors. |
| `read_network_requests` | What the page sent since the first call on that tab: method, address, status, type. |
| `session_adopt` | Work in a tab the person lent with the toolbar button, by id or address. It cannot be closed, and they can take it back at any moment. Recorded like any other work. |
| `handoff` | Give the tab to the person for a login, a one-time code, a payment or a bot check. A card on the page says who asks, why and on which site, and the toolbar button says WAIT. Only their click on the card or the button gives it back. The call waits with no model calls, and no tool can touch that tab meanwhile. What they type never reaches the agent. Recorded as a step. |
| `close_tab` | Close a tab you opened, or that a page opened because of what you did. Any other tab stays open. Not recorded. |
| `navigate` | Open an address in the agent tab. Pass `force` to leave a page that asks first. If an installed routine handles the page, it adds a hint line (see [Finding a routine first](#finding-a-routine-first)). |
| `read_page` | The page as an outline of roles and names. Interactive elements get a ref such as `ref_12`. Text a person can't see is left out. It waits up to 3 seconds for a page that is still drawing itself (`wait` changes that). The result is wrapped as [untrusted data](/docs/safety). Adds the same hint line when the tab has moved to a page a routine handles. |
| `page_llm_content` | The text the site publishes for models, when it has any: a Markdown version of this page, else `/llms.txt` or `/llms-full.txt`. Costs far less than `read_page`. See below. |
| `click` | Click an element by ref, or a point by `x` and `y` from your last screenshot. `button`, `count` (2 is a double click) and `modifiers` (`ctrl+shift`) are optional. |
| `hover` | Leave the pointer over a ref or a point, to open a menu or a tooltip. |
| `drag` | Press on one place and let go on another: a slider, a list to reorder, a map. Each end is a ref or a point, and both have to be on screen. |
| `scroll` | Turn the wheel: `direction` and `amount`, over the middle of the page or over a ref or a point. Only a `ref` brings that element into view. `click` and `type` do that by themselves. |
| `wait` | Wait some seconds. `read_page` with `wait` is usually better: it stops when the page is quiet. |
| `resize_window` | Make the page lay out at another size, as a narrow window or a phone would, to see a layout or a mobile site. It changes only that tab, not the person's window. `reset` goes back. Read the page again after it. |
| `script` | Do a whole task in one call with a short JavaScript program whose helpers are the step tools. See [A whole task in one script](#a-whole-task-in-one-script). |
| `batch` | Run up to 20 of these one after another in one call and get every answer back together: `navigate`, `read_page`, `find`, `get_page_text`, `click`, `hover`, `drag`, `scroll`, `type`, `press`, `select`, `form_input`, `wait`, `screenshot`, `dialog` and `resize_window`. Each runs as it would alone, with the same checks, pauses and recording, and the batch stops at the first one that fails. Uploads, scripts, hand-overs and secrets are not allowed in a batch. |
| `type` | Type into a field by ref. Replaces what is there. `submit` presses Enter after. |
| `select` | Pick an option in a select, by label or value. |
| `form_input` | Bring a field to a value: a checkbox, switch or radio (`true` or `false`), a select, a slider, a date, a time, a colour, or text. What is ticked already stays ticked. |
| `find` | Look for words on the page, with no model. Gives refs, controls first, including things a page made clickable without saying so. |
| `get_page_text` | The words of the page as a person reads them, for an article or a long result. |
| `download` | See what the browser has downloaded since the agent started, and get a file's path. If the browser asks where to save each file, that box belongs to the operating system and no tool can answer it: the download shows as `waiting_at_save_box`, and `download` with its id cancels it and fetches the file without the box (a second request for the address, or a read from the page for a file it made itself, so a one-time address cannot be fetched and a file made by the page has no name). See [A browser on another computer](remote.md) for what happens when the browser is there. |
| `remote_pair` | Give the person an address and a one-time code, to connect a browser on [another computer](remote.md). |
| `upload` | Attach files from this machine. Pass the `ref` of the file input, or of the button, label or drop zone in front of it, and an absolute `path` (or `paths` for several). See below. |
| `press` | Press keys in the focused element: Enter, Escape, ArrowDown, `ctrl+a`. Several, separated by spaces, go one after another; `repeat` presses it that many times. |
| `screenshot` | The area around the last element, or the whole tab with `full: true`, or part of the last picture enlarged with `region`. `read_page` costs less. |

### Options worth knowing

| Option | On | Does |
|---|---|---|
| `tab_id` | almost every browser tool | Acts on another tab of the session instead of the one the agent works in. `tabs` lists them. |
| `new_tab` | `navigate` | Opens the address in a new tab. `force` leaves a page that asks first, losing what it has not saved. |
| `filter`, `ref`, `wait` | `read_page` | `interactive` lists only what can be used, `all` everything. `ref` returns the full text of one element, up to 20000 characters. `wait` is how long, in milliseconds, it waits at most for a page still loading to go quiet (up to 10000). |
| `note` | `click`, `type`, `select`, `form_input`, `screenshot` | Up to 80 characters shown on that element in an annotated screenshot. |
| `pattern`, `only_errors`, `limit`, `clear` | `read_console_messages` | Only lines matching a regular expression, only errors, at most 500 lines, and forget them afterwards. |
| `url_contains`, `limit`, `clear` | `read_network_requests` | Only requests whose address contains the text, at most 500, and forget them afterwards. |
| `wait_seconds` | `handoff` | How long the call waits, 600 by default, 5 to 3000. When it runs out the card stays up, and the agent calls again to keep waiting. |
| `idle_minutes` | `tabs_cleanup` | Only close tabs untouched for that long. |
| `submit` | `type`, `type_secret` | Presses Enter after typing. |
| `format` | `recording` | `webm` or `mp4`. |
| `width`, `height`, `mobile`, `reset` | `resize_window` | A size from 200 to 3840 pixels, laid out as a phone with `mobile`, and back to the window's own size with `reset`. |
| `site` | `routines_search` | Only routines for that site. |

Everything these tools return that came from a page is [untrusted data](/docs/safety): wrapped between `BEGIN` and `END UNTRUSTED DATA` lines with a boundary that is new for each call, never instructions.

### A whole task in one script

`script` takes JavaScript (with `await`) that calls these helpers. Each helper is a step tool call, so the run is recorded and saves as a routine like any other. The script itself is never kept.

| Helper | Does |
|---|---|
| `open(url)` | Goes to a full address, or a path on the current site such as `/app/settings`. |
| `click(target)`, `type(target, text, {submit})`, `press(keys)` | As the tools of the same name. |
| `fill(target, value)`, `check(target, on)`, `select(target, value)` | Put a field, checkbox or list into a state. |
| `upload(target, absolutePath)` | Gives a file to a file input. |
| `wait(seconds)` | Waits. |
| `find(query)`, `read({all, full})`, `text()` | Return page text. `read` folds lines the last read already showed, such as a site menu, and long runs of rows that look alike; `full: true` shows everything. |
| `print(...)` | Adds to what comes back. Only what is printed or returned comes back. |
| `param(name, value)` | Returns `value` and marks it as what changes each run, as in `fill("Version", param("version", "2.15.0"))`. |
| `expect(text)` | Marks what the page says once the task worked. |

A target is the words on the element (its label, name or text, as `find` matches them) or a ref from `read_page`. Helpers run in the order they are called, awaited or not. The first that fails stops the script: the steps before it stay done, and the reply lists them and shows the page it stopped on, so guessing the next clicks from the task costs little when a guess is wrong.

`routine_propose` applies the `param` and `expect` marks, so a routine saved from a script run needs no edits for them. The code runs sandboxed, with no network, no files and no Node, and stops after 120 seconds unless `timeout_seconds` says otherwise (600 at most). Page text it reads is untrusted data.

### Video, flight recorder and network capture

| Tool | What it does |
|---|---|
| `recording` | Record a tab to WebM or MP4: `start`, `stop`, `status`, `cancel`. The agent's cursor and glow are left out unless `cursor` is true. The toolbar button says REC while it runs |
| `flight_recorder` | Keep the last minute of a tab: `start`, `status`, `save_last`, `cancel`. A routine that fails on a tab with it on saves it by itself, and `routine_run` takes `flight_recorder: true` for one run |
| `network` | Capture what a tab sends to a HAR file: `start`, `status`, `stop`, `cancel` |

The files go in `~/.agentic-routines/captures`, readable only by your account, and are deleted after 14 days. Video needs a Chromium browser.

These are built from pictures the browser takes of the tab, about 8 a second at best for `recording` and 2 for the flight recorder. A tab behind others gives fewer. The flight recorder's video plays 5 times faster than it happened, so that saving it takes seconds, not a minute. It costs some speed and memory while it is on, about 10 MB per tab.

A network capture leaves out response bodies and cookies, replaces the values of credential headers, and takes out anything that looks like a token or a password, along with stored secrets and passwords the agent typed. It stops accidents, not someone who is trying. Read a capture before you share it, as it still shows where you went.

### Secrets

| Tool | What it does |
|---|---|
| `secrets_list` | The secrets the person keeps: names and the one site each works on |
| `type_secret` | Type one into a field by name. It goes in only on the site it was kept for, and the value never comes back |

See [Secrets you keep for a site](safety.md#secrets-you-keep-for-a-site).

### Settings and status

| Tool | What it does |
|---|---|
| `settings` | Read or change the settings below. An agent changes these only when the person asks. The tool has no way to reach security settings or updates |
| `status` | The browsers connected, the session and its limits, its tabs and the settings in force |
| `tabs_cleanup` | Close the tabs this session opened and no longer needs |

| Setting | Values | Default |
|---|---|---|
| `tabs_where` | `auto` (this window, or a window of its own while another agent is working), `window` (this window), `separate` (a window for agents) | `auto` |
| `grouping` | `session` (a tab group per agent), `shared` (one group for all agents), `none` | `session` |
| `idle_close_minutes` | `0` (never), `10`, `30`, `60` | `30` |
| `agent_cursor` | Show the agent's cursor on the page | on |
| `handoff_notifications` | A desktop notification when an agent hands over a tab | on |
| `human_input` | Move and type at a person's pace (below) | off |

The person has the same settings in the panel, under their account menu. A change from either side shows in the panel at once. A tab an agent opened and left closes by itself after 30 minutes, unless that is turned off, it is the tab the person is looking at, a hand-over is waiting on it or a run is paused there. A tab the person opened or lent is never closed.

### Named sessions

An agent's tabs normally belong to its server, and close when it stops. A named session keeps them until it is told otherwise, and can be limited.

| Tool | What it does |
|---|---|
| `session_new` | Start one and work in it. `hosts` limits it to those sites and their subdomains, `read_only` stops it clicking, typing or running a routine |
| `session_list` | The sessions, their limits and their tabs |
| `session_use` | Work in one, by name. No name goes back to the server's own session |
| `session_reset` | Close the tabs it opened, and keep its name and limits |
| `session_delete` | Close them and forget it |
| `session_allowlist` | See its limits or tighten them |

A session stays in the browser profile it started in. If that profile is closed the agent is told, and nothing moves to another one. Start a server in a session with `AGENTIC_ROUTINES_SESSION=<name>`.

### At a person's pace

`settings` with `human_input: true`, or the switch in the side panel, makes input go at a person's pace in that browser. The pointer moves along a curve instead of jumping, a button stays down for a moment, keys come one at a time and scrolling glides. It is off by default, and slows every step down.

It is for pages that react to movement, such as a menu that opens on the way past or a canvas that follows the pointer, and for following along. Through `execute` or `cdp_endpoint` only the pointer's moves change.

It does not get you past a bot check, and that is not its job. It does not change what a page can read about the browser, and leaves the debugging bar at the top of the window, which a page cannot see but the person can. A site can still tell from how the session goes that it is not a person. When a check comes up the agent hands the tab to the person, with this on as with it off.

### Playwright code on the page

| Tool | What it does |
|---|---|
| `execute` | Runs Playwright code against the session's page. `page` and `context` are there, with `console`, timers and `files.write`. `return` gives a value back. |

Prefer the step tools on a page you have not seen. You cannot write code for a page you have not read, and looking costs a call either way. `execute` pays off for many small actions on a page you already know, such as reading a long table.

It runs in a V8 context on a thread of its own, without Node, network modules or `import`. Playwright's objects come through wrappers that refuse what would touch a file, start a browser or send requests from outside the page: a `path` option, `setInputFiles`, `route`, `browser()`, `storageState`. `files.write(name, data)` is the only way to a file, in a new folder for each call. Code that holds on for 2 seconds without yielding is stopped, as a whole call is after `timeout_seconds` (30 by default, 300 at most). What was already done stays done.

What it does is recorded with the run and listed in the result, with the values left out. It cannot become a routine, as a replay has no steps for it, and `routine_propose` says so.

### A DevTools address, for Playwright

| Tool | What it does |
|---|---|
| `cdp_endpoint` | A local address that speaks CDP, for `chromium.connectOverCDP` or anything else that does. |

This is the person's own browser with their sign-ins, reached through the extension's debugger. The browser's real debugging port stays closed. The endpoint starts when an agent first asks for it, and stops when nothing holds a token, so a person who never uses it has nothing listening. A token lasts as long as the agent's server runs, or eight hours; from the command line it lasts eight hours. The port is picked at random unless `AGENTIC_ROUTINES_CDP_PORT` sets one.

```js
const browser = await chromium.connectOverCDP(endpoint);
const page = browser.contexts()[0].pages()[0];
```

Prefer the step tools on a page you have not seen. They say what each step did, and only they record work that can become a routine. What is done through the endpoint is not recorded.

It needs a token and listens on `127.0.0.1` only. It refuses cross-site requests and any other `Host`. A client sees this session's tabs, and one client connects at a time. Cookie reads and writes, and site storage, are limited to the sites of those tabs. Clearing data, closing the browser, bringing a window to the front and `newContext` are refused, and so is a separate CDP session on a page. Downloads go where the browser sends them. A read-only session gets no endpoint, since CDP has no way to read without being able to touch. Once a stored secret is typed into a tab, nothing that could read it runs there until the tab goes to a new page.

### Points on the page

Most things have a ref, and a ref is better: it keeps working when the page moves. A point is for what has none: a canvas, a map, a place on a chart.

`x` and `y` are pixels in the last picture you took of that tab, whatever its size, so read them off the picture. Once the page has moved (a scroll, a new address) a point is refused until you take another picture, because it no longer means anything. `region` zooms into part of the picture, and points then count in the zoomed one.

In a routine, a point becomes what was under it: a click on a button is a click on that button, wherever it sits next time. On a canvas or something large, the step keeps the element and where on it, as a fraction of its size. If something else is drawn over that place when the routine runs, the step stops and does not click.

A hover a person makes while recording is not kept, since a pointer crosses a lot of things on its way. If a recorded task goes through a menu that only opens under the pointer, have the agent do that part with `hover`.

### Uploading files

Most upload widgets are a visible button in front of a hidden `<input type="file">`, or a drop zone with no input at all. Don't click them: that opens the operating system's file picker, which nobody can answer. Call `upload` with the ref `read_page` gave the button, label, drop zone or input, and the absolute path of the file:

```
upload { ref: "ref_14", path: "/home/me/builds/app-2.15.0.aab" }
upload { ref: "ref_14", paths: ["/home/me/a.pdf", "/home/me/b.pdf"] }
```

- The extension finds the input behind the ref, including one reached through a `<label>` or `aria-controls`. With no input, it dispatches a drop on the element. Several files need an input with `multiple` or a drop zone; the tool says when they don't fit.
- Each file is checked before the browser is involved: it has to exist, be a regular file and be readable. The error names the file and the problem.
- Files over 25 MB need a Chromium browser, which hands the file to the page directly. Over 2 GB is refused.
- Credential files are refused: anything in `~/.ssh`, `~/.aws`, `~/.gnupg`, `~/.kube`, browser profiles or Agentic Routines' own folder, `.env` files, private keys and similar. Only the person can change that, by setting `AGENTIC_ROUTINES_ALLOW_SENSITIVE_UPLOADS=1` for the agent.
- Only files the agent named in an `upload`, or the person typed for a routine, can be read by the extension. A page can't ask for another.
- A routine records the upload as a step with a `file` parameter. Run it with other paths; several files go one per line.

### Text made for models

`page_llm_content` asks the site for text written for models. It looks, in this order, for:

1. a `<link rel="alternate" type="text/markdown">` in the page,
2. the page's own address answered with `Accept: text/markdown`,
3. the same address ending in `.md` (`/docs/start.html` becomes `/docs/start.md`),
4. the site's `/llms.txt`, or `/llms-full.txt` when you pass `full: true`.

The result says which of those it was, whether it is about this page or the whole site, and the address it came from. If there is none it says so and lists what it tried. Nothing is fetched from any other site than the tab's, redirects off the site are refused, each request has a six second limit and `max_chars` caps the size. It is not a picture of the page: it has no refs, so use `read_page` to act.

The text is untrusted, like the page. Comments and hidden elements are removed from the Markdown and orders in it are marked.

## Finding a routine first

An agent should look for a routine before it does a browser task by hand. The server's instructions say so, and so do the tool descriptions of `navigate`, `read_page` and `routines_search`.

**The hint.** When `navigate` lands on, or `read_page` reads, a page that an installed routine handles, the result ends with one line per routine, at most two, best first:

```
Routine rt_play_release handles this page: release to a track. Prefer it.
```

The wording is fixed so that agents and skills can rely on it: `Routine <tool name> handles this page: <what it does>. Prefer it.` The tool name is the one in the tool list. A routine handles a page when one of its `urls` matches (see [Routine format](/docs/routines)); a routine that only shares the site gets no hint. `read_page` says it once per page, not on every read.

**Ranking.** `routines_search` orders by fit first, then by how well the routine has worked:

1. A routine whose `urls` match the page, with the closest path match first (more literal parts matched means closer).
2. A routine for the same site that lists other pages.
3. Among equals, the one that finishes more of its runs and needs the model less.

**Stats.** Each routine keeps a small record of the agent's runs of it on this machine: runs, how many finished, model calls per run, the median time and the last run, over the most recent 20. It is a file in the routine's folder. Nothing is sent anywhere, and it is not part of what you publish. `routines_list`, `routine_describe` and `routines_search` show it. Runs started from the side panel by a person are not counted.

## Routine tools

| Tool | What it does |
|---|---|
| `rt_<name>` | One tool per saved routine, with its parameters. Replays without a model. |
| `routine_run` | The same, by name, for clients that read tools only at startup. `match_viewport: true` sets the tab to the size the routine was recorded at and puts it back afterwards. |
| `routine_resume` | Continue a paused replay. `approve` goes past a pause or stops. `choice` picks the element for a changed step. Where the agent can ask you a question in its own window (Claude Code can), a pause is put to you there as Allow or Stop, and your answer goes straight to the extension; the model never sees a way to give it for you. A pause on someone else's routine that looks irreversible is settled the same way. Without that, the pause waits in the side panel and goes back to the agent after 90 seconds. |
| `routines_list` | Saved routines, what each is for and how the agent's runs of it have gone. Text from routines someone else wrote is shown as [untrusted data](/docs/safety). |
| `routine_describe` | The full notes: when to use it, when not to, the pages it applies to, how its runs have gone, values it asks for, where it pauses. |
| `run_steps` | The recorded steps of a run, numbered, as they happened. Labels come from pages, so the list is [untrusted data](/docs/safety). |
| `routine_playwright` | The routine's steps as a Playwright script. See [Routine format](routines.md). |
| `routine_propose` | After a task, the agent decides whether it is worth keeping. This turns the run into a draft: every step numbered, with its page, what it did and what happened after it, plus hints at what could go. Changes nothing. |
| `routine_edit` | Refine a draft: remove steps, replace clicks and dialogs with a direct address, make values parameters, add pauses and notes, undo, reset. The extension refuses unsafe edits. |
| `routine_test` | Replay the draft on the live site. Steps that pause are skipped, never performed. |
| `routine_save` | Save the draft as a routine. A routine that replaces a saved one needs a good test first. |

See [Refine a routine](/docs/refine) for the loop.

At most 30 routine tools are exposed at once. The rest are reached with `routines_list` and `routine_run`.

## Directory tools

| Tool | What it does |
|---|---|
| `routines_search` | Find routines for a page or a task. Pass `url` (the page you are on) and/or `query`. Installed routines come first, then the directory (no account needed) and the person's Git sources. A routine that lists the page you are on ranks above one that only matches the site. |
| `routine_install` | Ask to install `owner/name` from the directory. The extension fetches it and checks it again, and the side panel shows its name, description, notes and steps. Nothing is saved until the person clicks Install, so it waits for them and needs the browser open. Hooks stay off unless the person allows them there. |
| `routine_install_from_git` | Ask to install from a GitHub repository. The side panel shows every step and any hook code, and Install is the person's click. Hooks are off unless the person switches them on there. |
| `routine_publish` | Ask to send a routine for review. The person approves in the side panel. An agent can't publish by itself. |
| `routine_submissions` | Where each submission stands: waiting, rejected with the guideline, live or turned off. Read only. |

## A replay that stops

A replay returns one of these:

- **Done.** The result text lists the steps run and the time. It adds a note when the window was a very different size from the one the routine was recorded at (see [Viewport](/docs/how-it-works#window-size)).
- **Paused.** The next step can't be undone. Call `routine_resume` with `approve: true` to go on, or `false` to stop.
- **Needs a choice.** A step changed. The result shows the recorded and current crops as text and up to three candidate elements. Call `routine_resume` with the `ref` of the right one.
- **Failed.** The result says which step and why. A step that would leave the routine's site always fails here.

A routine written by someone else also pauses before any step that looks irreversible, even if its author didn't mark one, and only the person can approve that pause, in the side panel. [Untrusted content](/docs/safety) covers why.

## Frames and shadow roots

A page's outline includes every frame a person can see and whatever is inside shadow roots, open or closed. A ref in a frame says which one, like `f12:ref_3`, and works in `click`, `type`, `form_input` and the rest like any other ref. Frames that are hidden or too small to see are left out, so what they say never reaches you. A coordinate on a screenshot lands in whatever is drawn there, frame or not. Routines remember which frame a step was in by its address, and replay it there.

## Dialogs

An alert, confirm or prompt stops the page until someone answers. Every tool that needs the page then says so and quotes the dialog, and `dialog` answers it. The browser only reports dialogs on a tab with a debugging connection, which starts at the first click or key and lasts a minute after the last one. Behind another tab with no connection the browser answers no by itself. In front with no connection a dialog waits for the person. A dialog a person answers while recording is not captured.

## Scripts, the console and the network

These can reach what signs a person in, so they are held back on purpose:

- `javascript` runs on any website without asking, but never in a tab where a secret was typed until that tab goes to a new page. A script cannot read cookies, and the result has anything shaped like a token, key or cookie hidden.
- A script is never recorded. A routine made from the run will not do it, so use the other tools for anything worth keeping.
- `read_network_requests` gives no headers or bodies, and hides query values and long opaque parts of an address.
- Listening to the console and network starts at the first call on a tab, because some sites treat being listened to as a sign of a bot.

The hiding catches accidents. It would not stop a script written to get around it, which is why the person decides per site.
