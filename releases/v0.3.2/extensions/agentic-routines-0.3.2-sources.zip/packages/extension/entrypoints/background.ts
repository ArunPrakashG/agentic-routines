import { compileRun, hookHash, type CompileOptions, type PageFingerprint, type Routine, type Viewport } from '@agentic-routines/core';
import * as agent from '../lib/agent/agent';
import * as auth from '../lib/remote/auth';
import * as directory from '../lib/remote/directory';
import * as draft from '../lib/agent/draft';
import * as git from '../lib/remote/git';
import * as hooks from '../lib/replay/hooks';
import * as native from '../lib/agent/native';
import { onPrivateNetwork } from '../lib/agent/link';
import { platform } from '../lib/platform';
import * as replay from '../lib/replay/replay';
import * as runs from '../lib/agent/runs';
import { watchDialogs } from '../lib/page/dialogs';
import { watchLogs } from '../lib/page/logs';
import { fromCard, fromToolbar, handedOver, watchHandoffs } from '../lib/page/handoff';
import { videoPiece, watchCaptures } from '../lib/page/capture';
import { policyOf } from '../lib/page/policy';
import { handleRelay, watchRelay } from '../lib/page/relay';
import { scrub, scrubText, watchSecrets } from '../lib/page/secrets';
import { changeSettings, onSettingsChanged, settings } from '../lib/page/settings';
import { ask, heldBy, isLent, lend, lentTabs, releaseSession, takeBack, tellAll, watchTabs } from '../lib/page/tabs';
import type { PanelCommand, PanelState } from '../lib/panel/types';

// When each routine last ran and which steps changed then, by owner/name.
type LastRuns = Record<string, { id: string; at: number; changed: number[] }>;

export default defineBackground(() => {
  watchDialogs();
  watchTabs();
  watchHandoffs();
  watchLogs();

  // ---------- requests from the MCP server, through the host ----------
  // Whatever goes back to an agent, with any stored secret that has been used taken out of it.
  native.onRequest(async (method, p) => {
    try {
      return scrub(await answer(method, p));
    } catch (e) {
      throw new Error(scrubText((e as Error).message));
    }
  });
  const answer = async (method: string, p: any) => {
    if (method.startsWith('browser.') || method === 'runs.get' || method === 'runs.repeat') return agent.handle(method, p);
    if (method.startsWith('draft.')) return draft.handle(method, p);
    if (method.startsWith('cdp.')) return handleRelay(method, p);
    if (method === 'runs.markSaved') return runs.markSaved(p.run_id);
    if (method === 'runs.outside') return runs.noteOutside(agent.agentName(p.agent), p.did, p.url, p.session);
    // A rebuilt unpacked extension only runs after a reload. Waits so the answer gets out first.
    if (method === 'extension.reload') return void setTimeout(() => browser.runtime.reload(), 100);
    if (method === 'directory.publish') return askToPublish(p.id, agent.agentName(p.agent));
    // The status of what the person sent. Reading only: an agent cannot approve, withdraw or change any of it.
    if (method === 'directory.submissions') return directory.mine();
    // An agent can ask. The person reads the steps and clicks Install in the panel; nothing is installed before that.
    if (method === 'git.install') return askToInstall(String(p.source), String(p.path), agent.agentName(p.agent));
    if (method === 'replay.start' && policyOf(p?.session)?.readOnly) throw new Error('This session is read-only, so it cannot run a routine. Only the person can change that.');
    if (method === 'replay.start') return replay.start({ ...p, foreign: p.foreign === true || isForeign(p.routine) });
    if (method === 'replay.resume') return replay.resume(p);
    if (method === 'agent.hello') {
      agents.set(p?.session, agent.agentName(p?.agent));
      push();
      return true;
    }
    throw new Error(`Unknown method ${method}`);
  };

  /** Written by someone else: from the directory, a Git source or a folder. The list says so, not the routine. */
  function isForeign(r: Routine): boolean {
    const owner = (r as Routine & { owner?: string }).owner ?? r.meta.owner ?? 'local';
    return !!routines.find((x) => x.name === r.meta.name && x.owner === owner)?.origin;
  }

  onSettingsChanged(() => push());
  watchSecrets();
  watchCaptures();
  watchRelay();
  browser.notifications?.onClicked.addListener((id) => {
    const tabId = Number(/^handoff-(\d+)$/.exec(id)?.[1]);
    if (!tabId) return;
    void browser.tabs.update(tabId, { active: true }).then((t) => t && browser.windows.update(t.windowId, { focused: true })).catch(() => {});
    void browser.notifications?.clear(id);
  });

  // ---------- side panel ----------
  const panels = new Set<Browser.runtime.Port>();
  // Connected agents by session.
  const agents = new Map<string, string>();
  // As the host lists them: hooks carry the hash approval is pinned to, which becomes a state for the panel.
  let routines: (Omit<PanelState['routines'][number], 'hooks'> & { hooks?: { count: number; hash: string } })[] = [];
  let recording: { runId: string; tabId: number } | undefined;

  // A routine waiting for the person to say yes to making it public. An agent can ask; only the panel can approve.
  let publishing: { routine: Routine; card: directory.PublishCard; waiter?: { ok: (v: unknown) => void; no: (e: Error) => void } } | undefined;
  type Published = Record<string, { as: string; version: number }>;

  // The same for a routine from a Git source or a folder.
  type Waiter = { ok: (v: unknown) => void; no: (e: Error) => void };
  let installing: { card: git.GitCard; waiter?: Waiter } | undefined;
  // Hook code the person is reading from the library, to allow it or keep it off.
  let reviewing: NonNullable<PanelState['hooksReview']> & { hash: string } | undefined;

  function badge() {
    browser.action.setBadgeText({ text: recording ? 'REC' : (publishing && !publishing.card.done) || installing || scripting || replay.current()?.status === 'paused' ? '1' : '' });
  }

  // An agent's script runs with everything the page can reach, so the person says which sites. An agent can ask; only the panel can answer.
  let scripting: { card: NonNullable<PanelState['script']>; ok: () => void; no: (e: Error) => void } | undefined;
  const SCRIPT_WAIT_MS = 2 * 60_000;
  const scriptSites = async () => ((await browser.storage.local.get('scriptSites')) as { scriptSites?: string[] }).scriptSites ?? [];

  agent.askAboutScripts(async (site, code, by) => {
    if ((await scriptSites()).includes(site)) return;
    if (scripting) throw new Error('Another script is waiting for the user to say whether it may run. Try again after that.');
    await new Promise<void>((ok, no) => {
      const timer = setTimeout(() => {
        scripting = undefined;
        badge();
        void push();
        no(new Error('Nobody answered. Ask the user to open the side panel, then try again.'));
      }, SCRIPT_WAIT_MS);
      const done = () => {
        clearTimeout(timer);
        scripting = undefined;
        badge();
        void push();
      };
      scripting = {
        card: { site, code: code.slice(0, 2000), by },
        ok: () => (done(), ok()),
        no: (e) => (done(), no(e)),
      };
      badge();
      void push();
    });
  });

  async function decideScript(answer: 'no' | 'once' | 'always') {
    const s = scripting;
    if (!s) return;
    if (answer === 'no') return s.no(new Error('The user chose not to let that script run.'));
    if (answer === 'always') await browser.storage.local.set({ scriptSites: [...new Set([...(await scriptSites()), s.card.site])] });
    s.ok();
  }

  async function beginInstall(source: string, path: string, by?: string, waiter?: Waiter) {
    if (installing) throw new Error('Another routine is waiting for the user to approve installing it. Try again after that.');
    const card = await git.preview(source, path, by);
    installing = { card, waiter };
    badge();
    push();
  }

  function askToInstall(source: string, path: string, by: string) {
    return new Promise((ok, no) => beginInstall(source, path, by, { ok, no }).catch(no));
  }

  async function decideInstall(approve: boolean, allowHooks = false) {
    const i = installing;
    if (!i || i.card.busy) return;
    if (!approve) {
      i.waiter?.no(new Error('The user chose not to install it.'));
      installing = undefined;
      badge();
      return;
    }
    if (i.card.problems.length) return;
    i.card.busy = true;
    i.card.error = undefined;
    push();
    try {
      const saved = await git.install(i.card);
      const owner = (saved.meta as { owner?: string }).owner ?? '';
      // Approval is for the code the person read. If what got installed is not that (the source moved
      // between the preview and the click), the hooks stay off and the person is asked again from the library.
      const mine = saved.meta.hooks && Object.keys(saved.meta.hooks).length ? await hookHash(saved.meta.hooks) : undefined;
      const allowed = !!mine && allowHooks && mine === i.card.hookHash;
      if (allowed) await hooks.approve(`${owner}/${saved.meta.name}`, mine);
      i.waiter?.ok({ name: saved.meta.name, owner, version: saved.meta.version, steps: saved.steps.length, site: saved.meta.site, hooks: mine ? { count: Object.keys(saved.meta.hooks!).length, approved: allowed } : undefined });
      installing = undefined;
      await refreshRoutines();
    } catch (e) {
      i.card.error = (e as Error).message;
      i.card.busy = false;
    }
    badge();
  }

  async function beginPublish(id: string, by?: string, waiter?: NonNullable<typeof publishing>['waiter']) {
    if (publishing && !publishing.card.done) throw new Error('Another routine is waiting for the user to approve publishing it. Try again after that.');
    const account = await auth.account();
    if (!account) throw new Error('The user is not signed in. Ask them to sign in from the Agentic Routines side panel.');
    const r = await native.call<Routine & { owner: string }>('store.read', { id });
    if (r.owner !== 'local' && r.owner !== account.handle) throw new Error(`${r.meta.name} is by ${r.owner}, so it cannot be published from here.`);
    const issues = directory.problems(r);
    if (issues.length) throw new Error(issues.join(' '));
    const { shown, more } = directory.publicValues(r);
    publishing = {
      routine: r,
      waiter,
      card: { id, name: r.meta.name, site: r.meta.site, steps: r.steps.length, shown, more, needsHandle: !account.handle, handle: account.handle ?? undefined, by, busy: false },
    };
    badge();
    push();
  }

  /** Called by an agent: answers once the person approved in the panel and it is live, or said no. */
  function askToPublish(id: string, by: string) {
    return new Promise((ok, no) => beginPublish(id, by, { ok, no }).catch(no));
  }

  async function decidePublish(approve: boolean, handle?: string) {
    const p = publishing;
    if (!p) return;
    if (!approve) {
      if (!p.card.done) p.waiter?.no(new Error('The user chose not to publish it.'));
      publishing = undefined;
      badge();
      return;
    }
    if (p.card.done || p.card.busy) return;
    p.card.busy = true;
    p.card.error = undefined;
    push();
    try {
      if (p.card.needsHandle) {
        await directory.claimHandle((handle ?? '').trim().toLowerCase());
        p.card.needsHandle = false;
      }
      const out = await directory.publish(p.routine);
      p.card.done = { as: `${out.owner}/${out.name}`, version: out.version };
      const { published = {} } = (await browser.storage.local.get('published')) as { published?: Published };
      published[`${p.routine.meta.owner ?? 'local'}/${p.routine.meta.name}`] = p.card.done;
      await browser.storage.local.set({ published });
      p.waiter?.ok(out);
      p.waiter = undefined;
    } catch (e) {
      p.card.error = (e as Error).message;
    }
    p.card.busy = false;
    badge();
  }

  async function refreshRoutines() {
    try {
      routines = await native.call('store.list');
    } catch {
      routines = [];
    }
    push();
  }

  async function state(): Promise<PanelState> {
    const all = await runs.list();
    const r = replay.current();
    const { lastRuns = {} } = (await browser.storage.local.get('lastRuns')) as { lastRuns?: LastRuns };
    const { published = {} } = (await browser.storage.local.get('published')) as { published?: Published };
    return {
      account: await auth.account(),
      connected: native.connected(),
      link: await native.linkStatus(),
      agents: [...new Set(agents.values())],
      routines: await Promise.all(
        routines.map(async (x) => {
          const last = lastRuns[`${x.owner}/${x.name}`];
          const h = x.hooks && { count: x.hooks.count, ...(await hooks.stateFor(`${x.owner}/${x.name}`, x.hooks.hash)) };
          return { ...x, hooks: h && { count: h.count, state: h.state, reason: h.reason }, lastRun: last?.at, changed: last?.changed, draftedBy: x.draftedBy ? agent.agentName(x.draftedBy) : undefined, published: published[`${x.owner}/${x.name}`] };
        }),
      ),
      runs: all.filter((x) => !x.saved && x.events.length).map((x) => ({ id: x.id, source: x.source, startedAt: x.startedAt, updatedAt: x.updatedAt, events: x.events })),
      recording: recording?.runId,
      publish: publishing?.card,
      install: installing?.card,
      script: scripting?.card,
      scriptSites: await scriptSites(),
      settings: settings(),
      update: newer,
      lent: await Promise.all(
        lentTabs().map(async (id) => {
          const t = await browser.tabs.get(id).catch(() => undefined);
          let site = t?.url ?? '';
          try {
            site = new URL(site).host;
          } catch {
            // Shown as it is.
          }
          return { id, title: t?.title ?? '', site, by: heldBy(id)?.label };
        }),
      ),
      hooksReview: reviewing && { id: reviewing.id, name: reviewing.name, hooks: reviewing.hooks, state: reviewing.state, busy: reviewing.busy, error: reviewing.error },
      replay: r && {
        id: r.id,
        name: r.routine.meta.name,
        version: r.routine.meta.version,
        status: r.status,
        i: r.i,
        steps: r.routine.steps.map((s) => ({ n: s.n, action: s.action, label: s.label, value: s.value, pause: !!s.pause })),
        modelCalls: r.modelCalls,
        start: r.start,
        by: r.by && agent.agentName(r.by),
        handedBack: !!r.handedBack,
        fixed: Object.keys(r.fixes).map(Number),
        error: r.error,
        viewportNote: r.viewportNote || undefined,
        foreign: r.foreign,
        pauseKind: r.status === 'paused' ? r.pauseKind : undefined,
      },
    };
  }

  async function noteRun(s: replay.ReplayState) {
    if (s.status !== 'done' && s.status !== 'failed') return;
    const key = `${s.routine.meta.owner ?? 'local'}/${s.routine.meta.name}`;
    const { lastRuns = {} } = (await browser.storage.local.get('lastRuns')) as { lastRuns?: LastRuns };
    if (lastRuns[key]?.id === s.id) return;
    lastRuns[key] = { id: s.id, at: Date.now(), changed: Object.keys(s.fixes).map(Number) };
    await browser.storage.local.set({ lastRuns });
  }

  // ---------- update check ----------
  // A store updates its own copies. One loaded by hand never hears about a new release, so it asks GitHub, about once a day.
  let newer: { version: string; url: string } | undefined;
  const RELEASES = 'https://api.github.com/repos/ArunPrakashG/agentic-routines/releases/latest';
  const parts = (v: string) => v.replace(/^v/, '').split('.').map((n) => parseInt(n, 10) || 0);
  const isNewer = (a: string, b: string) => {
    const [x, y] = [parts(a), parts(b)];
    for (let i = 0; i < 3; i++) if ((x[i] ?? 0) !== (y[i] ?? 0)) return (x[i] ?? 0) > (y[i] ?? 0);
    return false;
  };
  async function checkUpdate() {
    try {
      const self = await browser.management.getSelf();
      if (self.installType === 'normal') return;
      const res = await fetch(RELEASES, { headers: { accept: 'application/vnd.github+json' } });
      if (!res.ok) return;
      const rel = (await res.json()) as { tag_name?: string; html_url?: string };
      const url = rel.html_url ?? '';
      const next = rel.tag_name && url.startsWith('https://github.com/ArunPrakashG/agentic-routines/') && isNewer(rel.tag_name, browser.runtime.getManifest().version) ? { version: rel.tag_name.replace(/^v/, ''), url } : undefined;
      if (next?.version !== newer?.version) {
        newer = next;
        void push();
      }
    } catch {
      // Offline, or GitHub is busy: asked again later.
    }
  }

  async function push() {
    if (!panels.size) return;
    const s = await state();
    for (const p of panels) p.postMessage(s);
  }

  native.onConnection((ok) => {
    if (ok) refreshRoutines();
    else push();
  });
  native.onHostEvent((e, data) => {
    if (e === 'agent.gone') {
      const { session } = data as { session: string };
      agents.delete(session);
      replay.agentGone(session);
      void releaseSession(session).then(push);
      return;
    }
    if (e === 'routines.changed') refreshRoutines();
  });
  runs.onRunsChanged(push);
  draft.onSaved(() => void refreshRoutines());
  browser.storage.onChanged.addListener((changes) => {
    if (changes.session) {
      push();
      if (native.connected()) native.hello().catch(() => {});
    }
  });
  // With several profiles open, an agent uses the one the person was last in unless told otherwise.
  browser.windows.onFocusChanged.addListener((id) => {
    if (id !== browser.windows.WINDOW_ID_NONE) native.emit('profile.focus');
  });
  replay.onReplay((s) => {
    badge();
    return noteRun(s).then(push);
  });

  async function setRecording(on: boolean) {
    if (on) {
      const [tab] = await browser.tabs.query({ active: true, lastFocusedWindow: true });
      if (!tab?.id) return;
      recording = { runId: await runs.startHuman(), tabId: tab.id };
      await tellAll(tab.id, { t: 'record', on: true });
      badge();
    } else if (recording) {
      await tellAll(recording.tabId, { t: 'record', on: false });
      recording = undefined;
      badge();
    }
    push();
  }

  async function toggleLend(tabId: number) {
    if (!isLent(tabId)) lend(tabId);
    else await giveBack(tabId);
    await push();
  }
  async function giveBack(tabId: number) {
    replay.stopOnTab(tabId);
    await takeBack(tabId);
  }

  async function command(c: PanelCommand): Promise<unknown> {
    switch (c.t) {
      case 'setting':
        await changeSettings(c.change);
        return;
      case 'linkPair':
        if (!onPrivateNetwork(c.address) && !c.acceptOpen) throw new Error('This address is not on a private network, so it needs your say-so.');
        await native.pair(c.address, c.code);
        return void push();
      case 'linkForget':
        await native.forget();
        return void push();
      case 'takeBack':
        await giveBack(c.tabId);
        return;
      case 'save': {
        const run = await runs.get(c.runId);
        const opts: CompileOptions = { name: c.name, description: c.description, fixed: c.fixed };
        const { routine } = compileRun(run, opts);
        const saved = await native.call<Routine>('store.write', { routine });
        await runs.markSaved(run.id);
        await refreshRoutines();
        // Saving is done either way; a publish that cannot start is not a failed save.
        if (c.publish) await beginPublish(`local/${saved.meta.name}`).catch(() => {});
        return;
      }
      case 'publish':
        return beginPublish(c.id);
      case 'publishDecide':
        return decidePublish(c.approve, c.handle);
      case 'scriptDecide':
        return decideScript(c.answer);
      case 'scriptForget':
        await browser.storage.local.set({ scriptSites: (await scriptSites()).filter((x) => x !== c.site) });
        return push();
      case 'sources':
        return git.list();
      case 'projects':
        return native.call('sources.projects');
      case 'share':
        return native.call('sources.share', { id: c.id, dir: c.dir });
      case 'sourceAdd':
        return git.add(c.address);
      case 'sourceRemove':
        return git.remove(c.id);
      case 'sourceSet':
        return git.setEnabled(c.id, c.enabled);
      case 'sourceEntries':
        return git.entries(c.id, c.fresh);
      case 'gitPreview':
        return beginInstall(c.source, c.path);
      case 'gitDecide':
        return decideInstall(c.approve, c.hooks);
      case 'hooksReview': {
        const r = await native.call<Routine & { owner?: string }>('store.read', { id: c.id });
        if (!r.meta.hooks || !Object.keys(r.meta.hooks).length) throw new Error('This routine has no hooks.');
        const st = await hooks.stateOf(c.id, r.meta.hooks);
        reviewing = { id: c.id, name: r.meta.name, hooks: r.meta.hooks, state: st.state, hash: st.hash! };
        return;
      }
      case 'hooksDecide': {
        const r = reviewing;
        reviewing = undefined;
        if (!r) return;
        // Only this click approves, and only the code that was on screen.
        if (c.approve) await hooks.approve(r.id, r.hash);
        else await hooks.revoke(r.id);
        return;
      }
      case 'enable':
        await native.call('store.setEnabled', { id: c.id, enabled: c.enabled });
        return refreshRoutines();
      case 'submissions':
        return directory.mine();
      case 'withdraw':
        return directory.withdraw(c.id);
      case 'discard':
        return runs.discard(c.runId);
      case 'inputs': {
        const r = await native.call<Routine>('store.read', { id: c.id });
        return { params: r.meta.params, secrets: r.meta.secrets };
      }
      case 'run': {
        const r = await native.call<Routine>('store.read', { id: c.id });
        // Secrets typed in the panel live only as long as this replay.
        const secrets = Object.fromEntries(r.meta.secrets.map((n) => [n, c.params[`secret:${n}`] ?? '']));
        // The person typed these paths here; the host checks them like any other upload.
        const files = Object.entries(r.meta.params).filter(([, sp]) => sp.type === 'file').flatMap(([k]) => (c.params[k] ?? '').split('\n').map((x) => x.trim()).filter(Boolean));
        if (files.length) await native.call('host.allowFiles', { paths: files });
        replay.start({ routine: r, params: c.params, secrets, foreign: isForeign(r), fit: c.fit }).catch(() => {});
        return;
      }
      case 'decide':
        return replay.panelDecide(c.id, c.approve);
      case 'stop':
        return replay.stop(c.id);
      case 'dismiss':
        return replay.dismiss();
      case 'record':
        return setRecording(c.on);
      case 'remove':
        await native.call('store.remove', { id: c.id });
        return refreshRoutines();
      case 'refresh':
        return refreshRoutines();
      case 'signIn':
        return auth.signIn(c.provider);
      case 'offered':
        return auth.offered();
      case 'passwordCode':
        return auth.passwordCode(c.email);
      case 'passwordSet':
        return auth.passwordSet(c.email, c.code, c.password);
      case 'passwordLogin':
        return auth.passwordLogin(c.email, c.password);
      case 'signOut':
        return auth.signOut();
    }
  }

  browser.runtime.onConnect.addListener((port) => {
    // Only the extension's own pages. A content script has the page's address, and must not reach what these commands can do.
    if (port.name !== 'panel' || !port.sender?.url?.startsWith(browser.runtime.getURL(''))) return;
    panels.add(port);
    port.onDisconnect.addListener(() => panels.delete(port));
    auth.check();
    port.onMessage.addListener(async (c: PanelCommand & { reqId?: number }) => {
      try {
        port.postMessage({ reqId: c.reqId, ok: true, result: await command(c) });
      } catch (e) {
        port.postMessage({ reqId: c.reqId, err: (e as Error).message });
      }
      push();
    });
    push();
  });

  // ---------- human demos ----------
  browser.runtime.onMessage.addListener((msg: any, sender, send) => {
    // Video on its way to a file, from the page that makes it. Nothing else here hears from that page.
    if (msg?.t === 'rec.piece' && sender.id === browser.runtime.id && !sender.tab) {
      videoPiece(msg.id, msg.data);
      send(true);
      return;
    }
    if (typeof msg?.t === 'string' && msg.t.startsWith('rec.')) return;
    if (msg?.t === 'handoff.continue') return void fromCard(sender, msg.nonce);
    if (msg?.t === 'recording?') return void send(!!recording && sender.tab?.id === recording.tabId);
    if (msg?.t !== 'human' || !recording || sender.tab?.id !== recording.tabId) return;
    if (!sender.frameId) return void runs.record('You', msg.event);
    // A step happens on the page the tab is on, whichever document in it was touched.
    const tabId = recording.tabId;
    void Promise.all([browser.tabs.get(tabId), ask<PageFingerprint>(tabId, { t: 'fingerprint' }).catch(() => undefined), ask<Viewport>(tabId, { t: 'viewport' }).catch(() => undefined)]).then(([tab, page, view]) => runs.record('You', { ...msg.event, url: tab.url ?? msg.event.url, page: page ?? msg.event.page, view: view ?? msg.event.view }));
  });
  browser.tabs.onUpdated.addListener((tabId, info) => {
    if (!recording || tabId !== recording.tabId) return;
    if (info.url) runs.markNavigated('You', info.url);
    if (info.status === 'complete') ask(tabId, { t: 'record', on: true }).catch(() => {});
  });
  browser.commands?.onCommand.addListener((cmd) => {
    if (cmd === 'record') setRecording(!recording);
  });

  platform.onToolbar((tab) => {
    // A tab that is with the person: this click is them giving it back.
    if (tab.id !== undefined && handedOver(tab.id)) {
      fromToolbar(tab.id);
      return false;
    }
    // One click lends a website's tab and opens the panel, which says so; the next takes it back. A tab an agent opened is not the person's to lend.
    if (tab.id !== undefined && /^https?:/.test(tab.url ?? '') && (isLent(tab.id) || !heldBy(tab.id))) void toggleLend(tab.id);
    return true;
  });
  browser.action.setBadgeBackgroundColor?.({ color: '#3530E0' });

  // The session stays out of reach of content scripts.
  (browser.storage.local as any).setAccessLevel?.({ accessLevel: 'TRUSTED_CONTEXTS' }).catch(() => {});

  // A link to another computer is only a socket, so a service worker that went to sleep comes back for it this way.
  browser.alarms.onAlarm.addListener((a) => {
    if (a.name === 'link') void native.connectLink();
    if (a.name === 'update') void checkUpdate();
  });

  // Chrome only wakes a service worker for an event, and agents need the host up.
  browser.alarms.create('update', { delayInMinutes: 1, periodInMinutes: 24 * 60 });
  browser.runtime.onStartup.addListener(() => {});
  browser.runtime.onInstalled.addListener(() => {});

  native.connect();
});
